#!/bin/bash

# 等待 Elasticsearch 启动
until curl -s http://elasticsearch:9200; do
  echo "Waiting for Elasticsearch to start..."
  sleep 2
done

# 创建索引1，存储zhipin对应的数据
curl -X PUT "http://elasticsearch:9200/zhipin_table" -H "Content-Type: application/json" -d'
{
  "mappings": {
    "dynamic_templates": [
      {
        "strings": {
          "match": "*",
          "mapping": {
            "type": "text",
            "fields": {
              "keyword": { "type": "keyword", "ignore_above": 256 }
            }
          }
        }
      }
    ],
    "properties": {
      "id": { "type": "keyword" },
      "position": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "company": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "city": { "type": "keyword" },
      "experience": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "degree": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "salary": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "companySize": { "type": "keyword" },
      "created_at": { "type": "date", "fields": { "keyword": { "type": "keyword" } } },
      "source": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "jobType": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "job_url": { "type": "keyword" }
    }
  }
}'

# 创建索引2，存储newcode对应的数据
curl -X PUT "http://elasticsearch:9200/newcode_crawler" -H "Content-Type: application/json" -d'
{
  "mappings": {
    "dynamic_templates": [
      {
        "strings": {
          "match": "*",
          "mapping": {
            "type": "text",
            "fields": {
              "keyword": { "type": "keyword", "ignore_above": 256 }
            }
          }
        }
      }
    ],
    "properties": {
      "position_id": { "type": "integer" },
      "position": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "salary": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "company": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "company_industry": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "company_scale": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "description": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "working_days": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "duration": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "location": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "created_at": { "type": "date", "fields": { "keyword": { "type": "keyword" } } },
      "page_type": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } }
    }
  }
}'

# 创建索引3，存储xiaohongshu对应的数据
curl -X PUT "http://elasticsearch:9200/xiaohongshu_table" -H "Content-Type: application/json" -d'
{
  "mappings": {
    "dynamic_templates": [
      {
        "strings": {
          "match": "*",
          "mapping": {
            "type": "text",
            "fields": {
              "keyword": { "type": "keyword", "ignore_above": 256 }
            }
          }
        }
      }
    ],
    "properties": {
      "position_id": { "type": "integer" },
      "note_id": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "title": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "author": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "user_id": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "likes": { "type": "integer" },
      "cover_url": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "image_urls": { "type": "text", "fields": { "keyword": { "type": "keyword", "ignore_above": 256 } } },
      "created_at": { "type": "date", "fields": { "keyword": { "type": "keyword" } } }
    }
  }
}'
