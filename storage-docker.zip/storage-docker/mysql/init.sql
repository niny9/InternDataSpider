-- 创建数据库
create database crawler_storage;

-- 选用数据库
USE crawler_storage;

-- 设置当地时间
SET SESSION time_zone = '+08:00';  ###当地时间

-- 创建表1，存储zhipin来源的爬虫数据
CREATE TABLE `zhipin_table` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '唯一标识',
  `position` VARCHAR(255) NOT NULL COMMENT '职位名称',
  `company` VARCHAR(255)  DEFAULT NULL COMMENT '公司名称',
  `city` VARCHAR(100) NOT NULL COMMENT '所在城市',
  `experience` VARCHAR(50) DEFAULT NULL COMMENT '经验要求（如：1-3年）',
  `degree` VARCHAR(50) DEFAULT NULL COMMENT '学历要求（如：本科及以上）',
  `salary` VARCHAR(50) DEFAULT NULL COMMENT '薪资范围（如：8k-15k）',
  `companySize` VARCHAR(50) DEFAULT NULL COMMENT '公司规模（如：10000人以上）',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：自动生成，与爬取时间对应',
  `source` VARCHAR(50) DEFAULT NULL COMMENT '爬取来源：牛客/小红书等',
  `jobType` VARCHAR(50) DEFAULT NULL COMMENT '职位类型：实习/春招等',
  `job_url` VARCHAR(50) DEFAULT NULL COMMENT 'url'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='职位信息表1';
  
-- 创建表2，存储newcode来源的爬虫数据
CREATE TABLE `newcode_crawler` (
  `position_id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '职位ID(主键)',
  `position` VARCHAR(255) NOT NULL COMMENT '职位名称',
  `salary` VARCHAR(50) DEFAULT NULL COMMENT '薪资范围',
  `company` VARCHAR(100) DEFAULT NULL COMMENT '公司名称',
  `company_industry` VARCHAR(100) DEFAULT NULL COMMENT '公司行业',
  `company_scale` VARCHAR(50) DEFAULT NULL COMMENT '公司规模',
  `description` TEXT DEFAULT NULL COMMENT '职位描述',
  `working_days` VARCHAR(20) DEFAULT NULL COMMENT '每周工作天数',
  `duration` VARCHAR(50) DEFAULT NULL COMMENT '实习时长要求',
  `location` VARCHAR(100) DEFAULT NULL COMMENT '工作地点',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `page_type` VARCHAR(50) NOT NULL DEFAULT 'intern_recruitment' COMMENT '页面类型'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='职位信息表2';

-- 创建表3，存储xiaohongshu来源的爬虫数据
CREATE TABLE xiaohongshu (
	position_id int auto_increment Unique COMMENT '职位ID',
	note_id VARCHAR(255) PRIMARY KEY COMMENT '笔记唯一标识',
    title VARCHAR(500) NOT NULL COMMENT '笔记标题',
    author VARCHAR(100) DEFAULT NULL COMMENT '作者名称（冗余存储，避免多表查询）',
    user_id VARCHAR(255) NOT NULL COMMENT '用户唯一标识',
    likes INT UNSIGNED DEFAULT 0 COMMENT '点赞数',
    cover_url VARCHAR(1024) NOT NULL COMMENT '封面图URL',
    image_urls JSON DEFAULT NULL COMMENT '图片URL数组（JSON格式存储）',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='职位信息表3';